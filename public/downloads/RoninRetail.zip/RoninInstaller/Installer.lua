--[[
    Ronin Retail - Installer V5.1.1
    Tank macros for GSE. Type /ronin to open the installer.
    Welcome screen -> installer -> thank-you panel. Resizable (drag the bottom-right corner).
]]

local addonName, Ronin = ...

RoninInstallerDB = RoninInstallerDB or {}
local DB = RoninInstallerDB

local VERSION  = "5.1.1"
local EDITION  = "Retail"
local FX_KIND  = "ring"          -- "ring" (Retail) or "infinity" (Forever)
local MEDIA    = "Interface\\AddOns\\RoninInstaller\\Media\\"
local WHITE    = "Interface\\Buttons\\WHITE8x8"

local ACCENT = "|cff00e5cc"
local GOLD   = "|cffe0b84a"
local GREEN  = "|cff7cfc00"
local RED    = "|cffff5555"
local DIM    = "|cff9aa5b8"

local C = {
    bg     = { 0.035, 0.050, 0.095, 0.985 },
    panel  = { 0.055, 0.075, 0.130, 0.95 },
    row    = { 0.050, 0.070, 0.120, 0.95 },
    gold   = { 0.82, 0.65, 0.24, 1 },
    cyan   = { 0.00, 0.80, 0.78, 1 },
    cyanDim= { 0.00, 0.45, 0.50, 0.55 },
    text   = { 0.88, 0.92, 1.00, 1 },
}

local LINKS = {
    { "Ko-fi",   "https://ko-fi.com/ron1n90c" },
    { "Website", "https://ron1n.cc" },
    { "Patreon", "https://www.patreon.com/RON1N90C" },
}

local THANKS = "Thank you for using Ronin!\n\n"
    .. "These macros are free and made by a player who just wants every tank to hold the pull "
    .. "with one key. If they helped you, a coffee, a follow or sharing the pack with a friend "
    .. "keeps the updates coming.\n\n"
    .. "See you in the dungeon."

local function Print(msg)
    print(ACCENT .. "[Ronin]|r " .. tostring(msg))
end

-- ---------------------------------------------------------------------------
-- Layout data: class rows -> sequences
-- ---------------------------------------------------------------------------

local GROUPS = {
    { name = "Protection Warrior", color = "|cffc69b6d", sub = "Mountain Thane  |  Colossus", seqs = { "RoninWarrior_Thane", "RoninWarrior_Colossus" }, specID = 73 },
    { name = "Protection Paladin", color = "|cfff48cba", sub = "Lightsmith  |  Templar", seqs = { "RoninPaladin_Lightsmith", "RoninPaladin_Templar" }, specID = 66 },
    { name = "Guardian Druid", color = "|cffff7c0a", sub = "Elune's Chosen  |  Druid of the Claw", seqs = { "RoninDruid_Elune", "RoninDruid_Claw" }, specID = 104 },
    { name = "Brewmaster Monk", color = "|cff00ff98", sub = "Master of Harmony  |  Shado-Pan", seqs = { "RoninBrewmaster_Harmony", "RoninBrewmaster_ShadoPan" }, specID = 268 },
    { name = "Vengeance Demon Hunter", color = "|cffa330c9", sub = "Aldrachi Reaver  |  Annihilator", seqs = { "RoninDH_Vengeance_Aldrachi", "RoninDH_Vengeance_Annihilator" }, specID = 581 },
    { name = "Blood Death Knight", color = "|cffc41e3a", sub = "Deathbringer  |  San'layn", seqs = { "RoninDK_Blood_Deathbringer", "RoninDK_Blood_Sanlayn" }, specID = 250 },
}

-- ---------------------------------------------------------------------------
-- Import logic
-- ---------------------------------------------------------------------------

local function DeepCopy(t)
    if type(t) ~= "table" then return t end
    local c = {}
    for k, v in pairs(t) do c[k] = DeepCopy(v) end
    return c
end

local function EnsureGSE()
    return type(GSE) == "table"
        and (type(GSE.ImportSerialisedSequence) == "function" or type(GSE.RegisterAddon) == "function")
end

local function FindSeq(name)
    if type(GSE) ~= "table" or type(GSE.Library) ~= "table" then return nil end
    for _, t in pairs(GSE.Library) do
        if type(t) == "table" and type(t[name]) == "table" then return t[name] end
    end
    return nil
end

local function IsInstalled(name)
    if FindSeq(name) then return true end
    if type(GSE) == "table" and type(GSE.FindSequenceId) == "function" then
        local ok, id = pcall(GSE.FindSequenceId, name, nil, true)
        return ok and id ~= nil
    end
    return false
end

-- Fingerprint of a sequence = hash of all macro texts in order (used to tell
-- "up to date" from "older / different version").
local function Collect(node, out, depth)
    if type(node) ~= "table" or depth > 14 then return end
    if type(node.macro) == "string" then out[#out + 1] = node.macro end
    local keys = {}
    for k in pairs(node) do
        if type(k) == "number" then keys[#keys + 1] = k end
    end
    table.sort(keys)
    for _, k in ipairs(keys) do Collect(node[k], out, depth + 1) end
end

local function Fingerprint(seq)
    if type(seq) ~= "table" or type(seq.Versions) ~= "table" then return nil end
    local vk, out = {}, {}
    for k in pairs(seq.Versions) do
        if type(k) == "number" then vk[#vk + 1] = k end
    end
    table.sort(vk)
    for _, k in ipairs(vk) do
        out[#out + 1] = "V" .. k
        local v = seq.Versions[k]
        if type(v) == "table" then Collect(v.Actions, out, 0) end
    end
    if #out == 0 then return nil end
    local str = table.concat(out, "\n")
    local h = 5381
    for i = 1, #str do h = (h * 33 + str:byte(i)) % 4294967296 end
    return string.format("%08x", h) .. ":" .. #str
end

-- "none" | "current" | "old" | "modified" | "other"
local function StatusOf(key)
    local lib = FindSeq(key)
    if not lib and not IsInstalled(key) then return "none" end
    local pkg = Fingerprint(Ronin.Sequences and Ronin.Sequences[key])
    local rec = DB.imported and DB.imported[key]
    local cur = lib and Fingerprint(lib) or nil
    if cur and pkg and cur == pkg then return "current" end
    if rec and pkg and rec.fp == pkg then
        if cur == nil or cur == rec.lib then return "current" end
        return "modified"
    end
    if rec then return "old", rec.v end
    return "other"
end

Ronin.StatusOf = StatusOf

local function RecordImport(keys)
    DB.imported = DB.imported or {}
    for _, key in ipairs(keys) do
        local pkg = Fingerprint(Ronin.Sequences and Ronin.Sequences[key])
        DB.imported[key] = { v = VERSION, fp = pkg, lib = Fingerprint(FindSeq(key)) }
    end
end

function Ronin.InstallBatch(keys, overwrite)
    if type(Ronin.Sequences) ~= "table" then
        return false, "Sequences table missing (Data.lua failed to load?)"
    end

    local gseVersion = tonumber(GSE.VersionNumber) or 3400
    local toc = tonumber((select(4, GetBuildInfo())))
    local members, names = {}, {}
    for _, key in ipairs(keys) do
        local src = Ronin.Sequences[key]
        if src then
            local seq = DeepCopy(src)
            seq.MetaData.GSEVersion = gseVersion
            seq.MetaData.TOC = toc
            members[key] = seq
            names[#names + 1] = key
        end
    end
    if #names == 0 then
        return false, "no matching sequences"
    end

    local collection = { type = "COLLECTION", payload = { Sequences = members } }

    -- Preferred: GSE's own importer. forcereplace = Overwrite toggle.
    if type(GSE.ImportSerialisedSequence) == "function" then
        local ok, err = pcall(GSE.ImportSerialisedSequence, collection, overwrite and true or false)
        if not ok then return false, err end
        return true
    end

    -- Fallback: register as an add-in pack (GSE_Utils not loaded).
    local ok, res = pcall(GSE.RegisterAddon, "RoninRetail", VERSION .. "-" .. tostring(time()), names, { collection })
    if not ok then return false, res end
    return true
end

-- ---------------------------------------------------------------------------
-- UI helpers (every call that might not exist on one client is wrapped)
-- ---------------------------------------------------------------------------

local function clamp(v, lo, hi)
    if v < lo then return lo elseif v > hi then return hi end
    return v
end

local function NewGroup(region, looping)
    local ok, ag = pcall(region.CreateAnimationGroup, region)
    if not ok or not ag then return nil end
    if looping then pcall(ag.SetLooping, ag, looping) end
    return ag
end

local function AddAnim(ag, kind, order, duration, setup)
    if not ag then return nil end
    local ok, a = pcall(ag.CreateAnimation, ag, kind)
    if not ok or not a then return nil end
    pcall(a.SetOrder, a, order)
    pcall(a.SetDuration, a, duration)
    if setup then pcall(setup, a) end
    return a
end

local function PlayGroup(ag) if ag then pcall(ag.Play, ag) end end

local function Pulse(region, from, to, dur)
    local ag = NewGroup(region, "BOUNCE")
    AddAnim(ag, "Alpha", 1, dur, function(a)
        a:SetFromAlpha(from); a:SetToAlpha(to); a:SetSmoothing("IN_OUT")
    end)
    PlayGroup(ag)
    return ag
end

local function Float(region, dy, dur)
    local ag = NewGroup(region, "BOUNCE")
    AddAnim(ag, "Translation", 1, dur, function(a)
        a:SetOffset(0, dy); a:SetSmoothing("IN_OUT")
    end)
    PlayGroup(ag)
    return ag
end

local function Spin(region, seconds)
    local ag = NewGroup(region, "REPEAT")
    AddAnim(ag, "Rotation", 1, seconds, function(a)
        a:SetDegrees(-360); a:SetOrigin("CENTER", 0, 0)
    end)
    PlayGroup(ag)
    return ag
end

local function FadeIn(frame)
    local ag = NewGroup(frame)
    AddAnim(ag, "Alpha", 1, 0.30, function(a)
        a:SetFromAlpha(0); a:SetToAlpha(1); a:SetSmoothing("OUT")
    end)
    return ag
end

local function MakeButton(parent, text, w, h, primary)
    local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
    b:SetSize(w, h)
    b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    local base  = primary and { 0.46, 0.34, 0.08, 1 } or { 0.07, 0.11, 0.19, 1 }
    local hover = primary and { 0.62, 0.47, 0.12, 1 } or { 0.10, 0.17, 0.28, 1 }
    local edge  = primary and C.gold or C.cyanDim
    b:SetBackdropColor(unpack(base))
    b:SetBackdropBorderColor(unpack(edge))
    local fs = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("CENTER", 0, 0)
    fs:SetText(text)
    fs:SetTextColor(primary and 1 or 0.78, primary and 0.92 or 0.95, primary and 0.70 or 1)
    b.label = fs
    b:SetScript("OnEnter", function(self)
        self:SetBackdropColor(unpack(hover))
        self:SetBackdropBorderColor(0.0, 0.9, 0.85, 1)
    end)
    b:SetScript("OnLeave", function(self)
        self:SetBackdropColor(unpack(base))
        self:SetBackdropBorderColor(unpack(edge))
    end)
    b:SetScript("OnMouseDown", function(self) self.label:SetPoint("CENTER", 0, -1) end)
    b:SetScript("OnMouseUp", function(self) self.label:SetPoint("CENTER", 0, 0) end)
    return b
end

local function GroupIcon(g)
    if g.specID and type(GetSpecializationInfoByID) == "function" then
        local ok, _, _, _, icon = pcall(GetSpecializationInfoByID, g.specID)
        if ok and icon then return icon end
    end
    return g.icon or "Interface\\Icons\\INV_Misc_QuestionMark"
end

-- ---------------------------------------------------------------------------
-- UI
-- ---------------------------------------------------------------------------

local frame, UI = nil, {}
local rows = {}
local overwrite = true

local function RefreshStatus()
    local needs = 0
    for _, r in ipairs(rows) do
        local n, cur, upd, old = #r.group.seqs, 0, 0, nil
        for _, key in ipairs(r.group.seqs) do
            local st, v = StatusOf(key)
            if st == "current" then cur = cur + 1
            elseif st ~= "none" then upd = upd + 1; old = old or v end
        end
        if cur == n then
            r.status:SetText(GREEN .. "Up to date|r  |TInterface\\Buttons\\UI-CheckBox-Check:16:16|t")
        elseif upd > 0 then
            needs = needs + 1
            r.status:SetText(GOLD .. "Update available|r" .. (old and (DIM .. "\nyou have V" .. tostring(old) .. "|r") or (DIM .. "\ndifferent version|r")))
        elseif cur > 0 then
            needs = needs + 1
            r.status:SetText(GOLD .. "Incomplete|r" .. DIM .. "\nimport to finish|r")
        else
            r.status:SetText(DIM .. "Not installed|r")
        end
    end
    return needs
end

local function SetStatusLine(text)
    if UI.msg then UI.msg:SetText(text or "") end
end

local function ShowPage(which)
    UI.welcome:Hide(); UI.install:Hide()
    local p = UI[which]
    p:Show()
    PlayGroup(p.fade)
    if which == "install" then
        local needs = RefreshStatus()
        if not EnsureGSE() then
            SetStatusLine(RED .. "GSE is not loaded or too old. Install/enable GSE first.|r")
        elseif needs > 0 then
            SetStatusLine(GOLD .. needs .. " row(s) can be installed or updated.|r " .. DIM .. "Keep Overwrite ON and press Import Selected.|r")
        else
            SetStatusLine(GREEN .. "Everything is up to date.|r")
        end
    end
end

local SPARKS = {
    { -0.30, -0.28, 0.0 }, { 0.32, -0.18, 0.6 }, { -0.42, 0.10, 1.3 }, { 0.40, 0.22, 1.9 },
    { -0.10, 0.40, 2.5 }, { 0.12, -0.42, 3.1 }, { -0.36, -0.40, 3.8 }, { 0.46, -0.02, 4.4 },
}

local function BuildFX(parent, strataFrame)
    -- background effect behind the logo: rotating orbit ring (Retail) or glowing infinity (Forever)
    local fx = parent:CreateTexture(nil, "BACKGROUND", nil, 1)
    fx:SetBlendMode("ADD")
    if FX_KIND == "infinity" then
        fx:SetTexture(MEDIA .. "Infinity.tga")
        Pulse(fx, 0.55, 1.0, 2.2)
    else
        fx:SetTexture(MEDIA .. "Ring.tga")
        Spin(fx, 48)
    end
    return fx
end

local function BuildLogo(parent, withSparks)
    local box = CreateFrame("Frame", nil, parent)
    box:SetSize(200, 200)

    local halo = box:CreateTexture(nil, "BACKGROUND", nil, 0)
    halo:SetTexture(MEDIA .. "Spark.tga")
    halo:SetBlendMode("ADD")
    halo:SetVertexColor(0.25, 0.55, 1.0, 0.55)
    halo:SetPoint("CENTER")
    box.halo = halo
    Pulse(halo, 0.35, 0.9, 2.4)

    local logo = box:CreateTexture(nil, "ARTWORK")
    logo:SetTexture(MEDIA .. "Logo.tga")
    logo:SetAllPoints(box)
    box.logo = logo

    local glow = box:CreateTexture(nil, "OVERLAY")
    glow:SetTexture(MEDIA .. "Logo.tga")
    glow:SetBlendMode("ADD")
    glow:SetAllPoints(box)
    box.glow = glow
    Pulse(glow, 0.0, 0.38, 1.9)

    box.sparks = {}
    if withSparks then
        for i, s in ipairs(SPARKS) do
            local t = box:CreateTexture(nil, "OVERLAY", nil, 2)
            t:SetTexture(MEDIA .. "Spark.tga")
            t:SetBlendMode("ADD")
            t:SetSize(16, 16)
            local ag = NewGroup(t, "REPEAT")
            AddAnim(ag, "Alpha", 1, s[3] + 0.01, function(a) a:SetFromAlpha(0); a:SetToAlpha(0) end)
            AddAnim(ag, "Alpha", 2, 1.1, function(a) a:SetFromAlpha(0); a:SetToAlpha(1) end)
            AddAnim(ag, "Translation", 2, 1.1, function(a) a:SetOffset(s[1] * 30, 22) end)
            AddAnim(ag, "Alpha", 3, 1.1, function(a) a:SetFromAlpha(1); a:SetToAlpha(0) end)
            AddAnim(ag, "Translation", 3, 1.1, function(a) a:SetOffset(s[1] * 30, 22) end)
            PlayGroup(ag)
            box.sparks[i] = { tex = t, fx = s[1], fy = s[2] }
        end
    end
    Float(box, 7, 2.6)
    return box
end

local function LayoutBox(box, size)
    box:SetSize(size, size)
    box.halo:SetSize(size * 1.9, size * 1.9)
    for _, s in ipairs(box.sparks) do
        s.tex:ClearAllPoints()
        s.tex:SetPoint("CENTER", box, "CENTER", s.fx * size, s.fy * size)
    end
end

local function Layout()
    if not frame then return end
    local w, h = frame:GetWidth(), frame:GetHeight()

    -- welcome page
    local ls = clamp(math.min(w * 0.52, h * 0.58), 150, 460)
    LayoutBox(UI.wlogo, ls)
    UI.wlogo:ClearAllPoints()
    UI.wlogo:SetPoint("CENTER", UI.welcome, "CENTER", 0, h * 0.07)
    UI.wfx:ClearAllPoints(); UI.wfx:SetPoint("CENTER", UI.wlogo, "CENTER", 0, 0)
    if FX_KIND == "infinity" then
        UI.wfx:SetSize(ls * 2.3, ls * 1.15)
    else
        UI.wfx:SetSize(ls * 2.5, ls * 2.5)
    end

    -- installer page header
    local headerH = clamp(h * 0.27, 112, 210)
    UI.header:SetHeight(headerH)
    local hs = headerH - 20
    LayoutBox(UI.hlogo, hs)
    UI.hlogo:ClearAllPoints()
    UI.hlogo:SetPoint("CENTER", UI.header, "CENTER", 0, 2)
    UI.hfx:ClearAllPoints(); UI.hfx:SetPoint("CENTER", UI.hlogo, "CENTER", 0, 0)
    if FX_KIND == "infinity" then
        UI.hfx:SetSize(hs * 3.2, hs * 1.6)
    else
        UI.hfx:SetSize(hs * 2.6, hs * 2.6)
    end

    -- rows
    local n = #rows
    local top = headerH + 10
    local bottom = 92
    local avail = h - top - bottom
    local gap = 6
    local rh = clamp(avail / n - gap, 34, 56)
    local usedH = n * rh + (n - 1) * gap
    local startY = top + math.max(0, (avail - usedH) / 2)
    for i, r in ipairs(rows) do
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", UI.install, "TOPLEFT", 22, -(startY + (i - 1) * (rh + gap)))
        r:SetPoint("TOPRIGHT", UI.install, "TOPRIGHT", -22, -(startY + (i - 1) * (rh + gap)))
        r:SetHeight(rh)
        r.icon:SetSize(rh - 12, rh - 12)
    end
end

local function BuildThanks()
    local t = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    t:SetPoint("TOPLEFT", 14, -14)
    t:SetPoint("BOTTOMRIGHT", -14, 14)
    t:SetFrameLevel(frame:GetFrameLevel() + 30)
    t:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    t:SetBackdropColor(0.03, 0.045, 0.09, 0.985)
    t:SetBackdropBorderColor(unpack(C.gold))
    t:EnableMouse(true)
    t:Hide()
    t.fade = FadeIn(t)

    local mini = t:CreateTexture(nil, "ARTWORK")
    mini:SetTexture(MEDIA .. "Logo.tga")
    mini:SetSize(64, 64)
    mini:SetPoint("TOP", 0, -18)

    local title = t:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", mini, "BOTTOM", 0, -8)
    title:SetText(GOLD .. "Support Ronin|r")

    local body = t:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    body:SetPoint("TOP", title, "BOTTOM", 0, -12)
    body:SetPoint("LEFT", 36, 0); body:SetPoint("RIGHT", -36, 0)
    body:SetJustifyH("CENTER")
    body:SetText(THANKS)
    body:SetSpacing(2)

    local hint = t:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    hint:SetTextColor(0.6, 0.67, 0.78)
    hint:SetText("Click a box, press Ctrl+C, then paste it in your browser.")

    local prev
    for i, l in ipairs(LINKS) do
        local lab = t:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        lab:SetText(ACCENT .. l[1] .. "|r")
        lab:SetWidth(64); lab:SetJustifyH("LEFT")

        local eb = CreateFrame("EditBox", nil, t, "BackdropTemplate")
        eb:SetAutoFocus(false)
        eb:SetFontObject("GameFontHighlightSmall")
        eb:SetHeight(26)
        eb:SetTextInsets(8, 8, 0, 0)
        eb:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
        eb:SetBackdropColor(0.02, 0.03, 0.06, 1)
        eb:SetBackdropBorderColor(unpack(C.cyanDim))
        eb:SetText(l[2]); eb:SetCursorPosition(0)
        eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
        eb:SetScript("OnEditFocusLost", function(self) self:HighlightText(0, 0) end)
        eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        eb:SetScript("OnTextChanged", function(self)
            if self:GetText() ~= l[2] then self:SetText(l[2]); self:HighlightText() end
        end)
        if prev then
            lab:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -14)
        else
            lab:SetPoint("TOPLEFT", body, "BOTTOMLEFT", 40, -22)
        end
        eb:SetPoint("LEFT", lab, "RIGHT", 10, 0)
        eb:SetPoint("RIGHT", t, "RIGHT", -60, 0)
        prev = lab
    end
    hint:SetPoint("TOP", prev, "BOTTOM", 0, -22)
    hint:SetPoint("LEFT", 36, 0); hint:SetPoint("RIGHT", -36, 0)

    local back = MakeButton(t, "Back", 120, 30, true)
    back:SetPoint("BOTTOM", 0, 22)
    back:SetScript("OnClick", function() t:Hide() end)
    return t
end

local function CreateFrameUI()
    if frame then return frame end

    frame = CreateFrame("Frame", "RoninInstallerFrame", UIParent, "BackdropTemplate")
    frame:SetSize(840, 620)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:SetResizable(true)
    frame:EnableMouse(true)
    frame:SetClampedToScreen(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 2 })
    frame:SetBackdropColor(unpack(C.bg))
    frame:SetBackdropBorderColor(unpack(C.gold))
    tinsert(UISpecialFrames, "RoninInstallerFrame") -- Esc closes it

    if frame.SetResizeBounds then
        frame:SetResizeBounds(780, 540, 1200, 900)
    else
        if frame.SetMinResize then frame:SetMinResize(780, 540) end
        if frame.SetMaxResize then frame:SetMaxResize(1200, 900) end
    end

    -- thin inner line
    local inner = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    inner:SetPoint("TOPLEFT", 6, -6)
    inner:SetPoint("BOTTOMRIGHT", -6, 6)
    inner:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
    inner:SetBackdropColor(0.02, 0.03, 0.07, 0.55)
    inner:SetBackdropBorderColor(0.0, 0.55, 0.60, 0.40)
    UI.inner = inner

    local close = MakeButton(frame, "X", 24, 24, false)
    close:SetPoint("TOPRIGHT", -12, -12)
    close:SetFrameLevel(frame:GetFrameLevel() + 20)
    close:SetScript("OnClick", function() frame:Hide() end)

    ---------------------------------------------------------------- WELCOME
    local welcome = CreateFrame("Frame", nil, inner)
    welcome:SetAllPoints(inner)
    welcome.fade = FadeIn(welcome)
    UI.welcome = welcome
    UI.wfx = BuildFX(welcome)
    UI.wlogo = BuildLogo(welcome, true)

    local wtitle = welcome:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    wtitle:SetPoint("BOTTOM", welcome, "BOTTOM", 0, 78)
    wtitle:SetText(ACCENT .. "Welcome|r")
    local wsub = welcome:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    wsub:SetPoint("TOP", wtitle, "BOTTOM", 0, -6)
    wsub:SetText(DIM .. EDITION .. " tank macros for GSE  -  V" .. VERSION .. "|r")

    local skip = CreateFrame("CheckButton", nil, welcome, "UICheckButtonTemplate")
    skip:SetSize(24, 24)
    skip:SetPoint("BOTTOMLEFT", 20, 18)
    skip:SetChecked(DB.skipWelcome and true or false)
    skip:SetScript("OnClick", function(self) DB.skipWelcome = self:GetChecked() and true or false end)
    local skipTxt = welcome:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    skipTxt:SetPoint("LEFT", skip, "RIGHT", 4, 1)
    skipTxt:SetTextColor(0.6, 0.67, 0.78)
    skipTxt:SetText("Don't show this screen again")

    local wthanks = MakeButton(welcome, "Thank you", 110, 30, false)
    wthanks:SetPoint("BOTTOM", 0, 18)
    wthanks:SetScript("OnClick", function() UI.thanks:Show(); PlayGroup(UI.thanks.fade) end)

    local nextBtn = CreateFrame("Button", nil, welcome)
    nextBtn:SetSize(48, 48)
    nextBtn:SetPoint("BOTTOMRIGHT", -16, 10)
    nextBtn:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up")
    nextBtn:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Down")
    nextBtn:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    nextBtn:SetScript("OnClick", function() ShowPage("install") end)
    Pulse(nextBtn, 0.55, 1.0, 0.9)
    local nextTxt = welcome:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    nextTxt:SetPoint("RIGHT", nextBtn, "LEFT", -2, 0)
    nextTxt:SetText(GOLD .. "Continue|r")

    ---------------------------------------------------------------- INSTALLER
    local install = CreateFrame("Frame", nil, inner)
    install:SetAllPoints(inner)
    install.fade = FadeIn(install)
    UI.install = install

    local header = CreateFrame("Frame", nil, install)
    header:SetPoint("TOPLEFT", 0, 0)
    header:SetPoint("TOPRIGHT", 0, 0)
    header:SetHeight(130)
    pcall(header.SetClipsChildren, header, true)
    UI.header = header
    UI.hfx = BuildFX(header)
    UI.hlogo = BuildLogo(header, false)

    local ver = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ver:SetPoint("BOTTOMLEFT", 16, 8)
    ver:SetText(DIM .. EDITION .. "  V" .. VERSION .. "|r")

    local back = CreateFrame("Button", nil, install)
    back:SetSize(36, 36)
    back:SetPoint("TOPLEFT", 10, -8)
    back:SetNormalTexture("Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Up")
    back:SetPushedTexture("Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Down")
    back:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
    back:SetScript("OnClick", function() ShowPage("welcome") end)

    local sep = install:CreateTexture(nil, "ARTWORK")
    sep:SetColorTexture(0.82, 0.65, 0.24, 0.35)
    sep:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 22, 0)
    sep:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", -22, 0)
    sep:SetHeight(1)

    for _, g in ipairs(GROUPS) do
        local row = CreateFrame("Button", nil, install, "BackdropTemplate")
        row:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
        row:SetBackdropColor(unpack(C.row))
        row:SetBackdropBorderColor(0.10, 0.20, 0.30, 1)
        row.group = g

        local cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
        cb:SetSize(26, 26)
        cb:SetPoint("LEFT", 8, 0)
        cb:SetChecked(true)
        cb:EnableMouse(false)
        row.cb = cb

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetPoint("LEFT", cb, "RIGHT", 8, 0)
        icon:SetTexture(GroupIcon(g))
        icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
        row.icon = icon

        local name = row:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        name:SetPoint("LEFT", icon, "RIGHT", 12, 5)
        name:SetText(g.color .. g.name .. "|r")
        local sub = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        sub:SetPoint("TOPLEFT", name, "BOTTOMLEFT", 0, -2)
        sub:SetText(DIM .. (g.sub or "") .. "|r")

        local status = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        status:SetPoint("RIGHT", -14, 0)
        status:SetJustifyH("RIGHT")
        row.status = status

        row:SetScript("OnClick", function() cb:SetChecked(not cb:GetChecked()) end)
        row:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(0.0, 0.8, 0.78, 0.9) end)
        row:SetScript("OnLeave", function(self) self:SetBackdropBorderColor(0.10, 0.20, 0.30, 1) end)
        rows[#rows + 1] = row
    end

    -- bottom bar
    local bar = CreateFrame("Frame", nil, install)
    bar:SetPoint("BOTTOMLEFT", 0, 0)
    bar:SetPoint("BOTTOMRIGHT", 0, 0)
    bar:SetHeight(92)

    UI.msg = bar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    UI.msg:SetPoint("BOTTOM", bar, "TOP", 0, 2)

    local importBtn = MakeButton(bar, "Import Selected", 170, 38, true)
    importBtn:SetPoint("BOTTOMRIGHT", -24, 22)

    local noneBtn = MakeButton(bar, "Select None", 116, 38, false)
    noneBtn:SetPoint("RIGHT", importBtn, "LEFT", -18, 0)
    local allBtn = MakeButton(bar, "Select All", 116, 38, false)
    allBtn:SetPoint("RIGHT", noneBtn, "LEFT", -18, 0)

    local thanksBtn = MakeButton(bar, "Thank you", 116, 38, false)
    thanksBtn:SetPoint("BOTTOMLEFT", 24, 22)
    thanksBtn:SetScript("OnClick", function() UI.thanks:Show(); PlayGroup(UI.thanks.fade) end)

    local owBtn = MakeButton(bar, "", 160, 38, false)
    owBtn:SetPoint("LEFT", thanksBtn, "RIGHT", 18, 0)
    local function OwText()
        owBtn.label:SetText("Overwrite: " .. (overwrite and (GREEN .. "ON|r") or (RED .. "OFF|r")))
    end
    OwText()
    owBtn:SetScript("OnClick", function() overwrite = not overwrite; OwText() end)

    allBtn:SetScript("OnClick", function() for _, r in ipairs(rows) do r.cb:SetChecked(true) end end)
    noneBtn:SetScript("OnClick", function() for _, r in ipairs(rows) do r.cb:SetChecked(false) end end)

    importBtn:SetScript("OnClick", function()
        if not EnsureGSE() then
            SetStatusLine(RED .. "GSE is not loaded or too old.|r"); return
        end
        if InCombatLockdown() then
            SetStatusLine(RED .. "Leave combat first.|r"); return
        end
        local selected = {}
        for _, r in ipairs(rows) do
            if r.cb:GetChecked() then
                for _, key in ipairs(r.group.seqs) do
                    if overwrite or not IsInstalled(key) then selected[#selected + 1] = key end
                end
            end
        end
        if #selected == 0 then
            SetStatusLine(DIM .. "Nothing to import (tick a row, or turn Overwrite ON to replace).|r"); return
        end
        local ok, err = Ronin.InstallBatch(selected, overwrite)
        if ok then
            SetStatusLine(GREEN .. "Imported " .. #selected .. " sequence(s).|r " .. DIM .. "Bind them in GSE and place the macro on your bar.|r")
            Print(GREEN .. "Imported " .. #selected .. " sequence(s).|r Bind them in GSE.")
            RecordImport(selected)
            RefreshStatus()
            if type(C_Timer) == "table" and C_Timer.After then
                C_Timer.After(1.5, function() RecordImport(selected); RefreshStatus() end)
            end
        else
            SetStatusLine(RED .. "Import failed: " .. tostring(err) .. "|r")
            Print(RED .. "Import failed: " .. tostring(err))
        end
    end)

    ---------------------------------------------------------------- THANKS
    UI.thanks = BuildThanks()

    ---------------------------------------------------------------- RESIZE GRIP
    local grip = CreateFrame("Button", nil, frame)
    grip:SetSize(20, 20)
    grip:SetPoint("BOTTOMRIGHT", -3, 3)
    grip:SetFrameLevel(frame:GetFrameLevel() + 40)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetScript("OnMouseDown", function() frame:StartSizing("BOTTOMRIGHT") end)
    grip:SetScript("OnMouseUp", function() frame:StopMovingOrSizing() Layout() end)

    frame:SetScript("OnSizeChanged", Layout)
    frame:SetScript("OnShow", function()
        Layout()
        ShowPage(DB.skipWelcome and "install" or "welcome")
    end)
    Layout()
    frame:Hide()
    return frame
end

SLASH_RONIN1 = "/ronin"
SLASH_RONIN2 = "/ronininstaller"
SlashCmdList["RONIN"] = function()
    local f = CreateFrameUI()
    if f:IsShown() then f:Hide() else f:Show() end
end

local seqCount = 0
if Ronin.Sequences then
    for _ in pairs(Ronin.Sequences) do seqCount = seqCount + 1 end
end
Print(ACCENT .. "Ronin " .. EDITION .. " V" .. VERSION .. "|r loaded. Sequences: " .. seqCount .. ". Type |cffffffff/ronin|r")
