--[[
    Ronin Forever - Installer V1.5.1
    Tank Priority Edition for WoW: Forever. Type /ronin to open the installer.
]]

local addonName, Ronin = ...

RoninForeverDB = RoninForeverDB or {}

local ACCENT = "|cff00e5cc"
local GOLD   = "|cffffd100"
local GREEN  = "|cff7cfc00"
local RED    = "|cffff5555"
local DIM    = "|cffaaaaaa"
local VERSION = "1.5.1"

local function Print(msg)
    print(ACCENT .. "[Ronin]|r " .. tostring(msg))
end

-- ---------------------------------------------------------------------------
-- Layout data: class groups -> sequences
-- ---------------------------------------------------------------------------

local GROUPS = {
    { name = "Protection Paladin", color = "|cfff48cba", seqs = {
        { "RoninForever_Paladin", "Protection" } } },
    { name = "Protection Warrior", color = "|cffc69b6d", seqs = {
        { "RoninForever_Warrior", "Protection" } } },
    { name = "Feral Druid (Bear)", color = "|cffff7c0a", seqs = {
        { "RoninForever_Druid", "Feral Tank" } } },
}

-- ---------------------------------------------------------------------------
-- Import logic
-- ---------------------------------------------------------------------------

local function DeepCopy(t)
    if type(t) ~= "table" then return t end
    local c = {}
    for k, v in pairs(t) do c[k] = DeepCopy(v) end
    return c
end

local function EnsureGSE()
    return type(GSE) == "table"
        and (type(GSE.ImportSerialisedSequence) == "function" or type(GSE.RegisterAddon) == "function")
end

local function IsInstalled(name)
    if type(GSE) == "table" and type(GSE.FindSequenceId) == "function" then
        local ok, id = pcall(GSE.FindSequenceId, name, nil, true)
        return ok and id ~= nil
    end
    return false
end

function Ronin.InstallBatch(keys, overwrite)
    if type(Ronin.Sequences) ~= "table" then
        return false, "Sequences table missing (Data.lua failed to load?)"
    end

    local gseVersion = tonumber(GSE.VersionNumber) or 3400
    local toc = tonumber((select(4, GetBuildInfo())))
    local members, names = {}, {}
    for _, key in ipairs(keys) do
        local src = Ronin.Sequences[key]
        if src then
            local seq = DeepCopy(src)
            seq.MetaData.GSEVersion = gseVersion
            seq.MetaData.TOC = toc
            members[key] = seq
            names[#names + 1] = key
        end
    end
    if #names == 0 then
        return false, "no matching sequences"
    end

    local collection = { type = "COLLECTION", payload = { Sequences = members } }

    -- Preferred: GSE's own importer. forcereplace = Overwrite checkbox.
    if type(GSE.ImportSerialisedSequence) == "function" then
        local ok, err = pcall(GSE.ImportSerialisedSequence, collection, overwrite and true or false)
        if not ok then return false, err end
        return true
    end

    -- Fallback: register as an add-in pack (GSE_Utils not loaded).
    local ok, res = pcall(GSE.RegisterAddon, "RoninForever", VERSION .. "-" .. tostring(time()), names, { collection })
    if not ok then return false, res end
    return true
end

-- ---------------------------------------------------------------------------
-- UI
-- ---------------------------------------------------------------------------

local frame, checks, overwriteCB = nil, {}, nil

local function CreateFrameUI()
    if frame then return frame end

    local ROW_H, HEADER_H, GAP = 24, 20, 10
    local height = 36 + 12 + (#GROUPS * (HEADER_H + ROW_H + GAP)) + 56 + 6

    frame = CreateFrame("Frame", "RoninForeverFrame", UIParent, "BackdropTemplate")
    frame:SetSize(480, height)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetClampedToScreen(true)
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
        insets = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    frame:SetBackdropColor(0.08, 0.08, 0.10, 0.97)
    frame:SetBackdropBorderColor(0.00, 0.90, 0.80, 0.6)
    tinsert(UISpecialFrames, "RoninForeverFrame") -- Esc closes it

    -- Title bar
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetPoint("TOPLEFT", 1, -1)
    titleBar:SetPoint("TOPRIGHT", -1, -1)
    titleBar:SetHeight(36)
    titleBar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
    titleBar:SetBackdropColor(0.06, 0.06, 0.08, 1)

    local title = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("LEFT", 16, 0)
    title:SetText(ACCENT .. "Ronin|r Forever V" .. VERSION)

    local subtitle = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    subtitle:SetPoint("LEFT", title, "RIGHT", 12, 0)
    subtitle:SetText(DIM .. "Tank Priority Edition")

    local close = CreateFrame("Button", nil, titleBar, "UIPanelCloseButton")
    close:SetPoint("RIGHT", -4, 0)
    close:SetScript("OnClick", function() frame:Hide() end)

    -- Content
    local content = CreateFrame("Frame", nil, frame)
    content:SetPoint("TOPLEFT", 16, -48)
    content:SetPoint("BOTTOMRIGHT", -16, 58)

    local y = 0
    for _, g in ipairs(GROUPS) do
        local hdr = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        hdr:SetPoint("TOPLEFT", 0, y)
        hdr:SetText(g.color .. g.name .. "|r")
        y = y - HEADER_H

        for i, s in ipairs(g.seqs) do
            local cb = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
            cb:SetSize(22, 22)
            cb:SetPoint("TOPLEFT", (i - 1) * 220 + 4, y)
            cb:SetChecked(true)
            cb:SetHitRectInsets(0, -170, 0, 0)
            local txt = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            txt:SetPoint("LEFT", cb, "RIGHT", 2, 0)
            txt:SetText(s[2])
            checks[s[1]] = cb
        end
        y = y - ROW_H - GAP
    end

    -- Bottom bar
    local bottom = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    bottom:SetPoint("BOTTOMLEFT", 1, 1)
    bottom:SetPoint("BOTTOMRIGHT", -1, 1)
    bottom:SetHeight(52)
    bottom:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
    bottom:SetBackdropColor(0.06, 0.06, 0.08, 1)

    overwriteCB = CreateFrame("CheckButton", nil, bottom, "UICheckButtonTemplate")
    overwriteCB:SetPoint("LEFT", 12, 0)
    overwriteCB:SetSize(22, 22)
    overwriteCB:SetChecked(true)
    overwriteCB:SetHitRectInsets(0, -80, 0, 0)
    local ovTxt = overwriteCB:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    ovTxt:SetPoint("LEFT", overwriteCB, "RIGHT", 2, 0)
    ovTxt:SetText("Overwrite")

    local importBtn = CreateFrame("Button", nil, bottom, "UIPanelButtonTemplate")
    importBtn:SetSize(130, 28)
    importBtn:SetPoint("RIGHT", -14, 0)
    importBtn:SetText(ACCENT .. "Import Selected|r")
    importBtn:SetScript("OnClick", function()
        if not EnsureGSE() then
            Print(RED .. "GSE is not loaded or too old.")
            return
        end
        if InCombatLockdown() then
            Print(RED .. "Leave combat first.")
            return
        end
        local overwrite = overwriteCB:GetChecked() and true or false
        local selected = {}
        for _, g in ipairs(GROUPS) do
            for _, s in ipairs(g.seqs) do
                local key = s[1]
                if checks[key]:GetChecked() and (overwrite or not IsInstalled(key)) then
                    selected[#selected + 1] = key
                end
            end
        end
        if #selected == 0 then
            Print(DIM .. "Nothing selected, or already installed (tick Overwrite to replace).")
            return
        end
        local ok, err = Ronin.InstallBatch(selected, overwrite)
        if ok then
            Print(GREEN .. "Imported " .. #selected .. " sequence(s).|r Bind them in GSE.")
            frame:Hide()
        else
            Print(RED .. "Import failed: " .. tostring(err))
        end
    end)

    local selectAll = CreateFrame("Button", nil, bottom, "UIPanelButtonTemplate")
    selectAll:SetSize(80, 28)
    selectAll:SetPoint("RIGHT", importBtn, "LEFT", -6, 0)
    selectAll:SetText("All")
    selectAll:SetScript("OnClick", function()
        for _, cb in pairs(checks) do cb:SetChecked(true) end
    end)

    local selectNone = CreateFrame("Button", nil, bottom, "UIPanelButtonTemplate")
    selectNone:SetSize(80, 28)
    selectNone:SetPoint("RIGHT", selectAll, "LEFT", -6, 0)
    selectNone:SetText("None")
    selectNone:SetScript("OnClick", function()
        for _, cb in pairs(checks) do cb:SetChecked(false) end
    end)

    frame:Hide()
    return frame
end

SLASH_RONINFOREVER1 = "/ronin"
SLASH_RONINFOREVER2 = "/roninforever"
SlashCmdList["RONINFOREVER"] = function()
    local f = CreateFrameUI()
    if f:IsShown() then f:Hide() else f:Show() end
end

local seqCount = 0
if Ronin.Sequences then
    for _ in pairs(Ronin.Sequences) do seqCount = seqCount + 1 end
end
Print(ACCENT .. "Ronin Forever V" .. VERSION .. "|r loaded. Sequences: " .. seqCount .. ". Type |cffffffff/ronin|r")
