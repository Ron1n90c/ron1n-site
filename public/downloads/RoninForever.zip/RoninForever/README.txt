Ronin Forever V1.5.0 - tank macros for GSE, WoW: Forever (Interface 16001)

Install: copy the RoninForever folder to Interface\AddOns, make sure GSE is enabled,
log in, type /ronin (or /roninforever), tick the sequences and press Import Selected.
Then put the GSE macro on your action bar. AFTER EVERY GSE UPDATE the macros must be
put on the action bar again.

Sequences (all with the same 3 versions: Leveling 1-20, Leveling 20-40, 60):
- RoninForever_Paladin  Protection: Seal of Fury + Judgement x3 (castsequence), Holy
  Strike, Exorcism, Consecration, Holy Shield, Hammer of the Righteous. Righteous Fury
  and below level 10 the seal are cast by you.
- RoninForever_Warrior  Protection (Defensive Stance): Shield Slam, Revenge, Sunder
  Armor, Shield Block, Thunder Clap / Demoralizing Shout / Battle Shout, Bloodrage.
- RoninForever_Druid    Feral tank: EVERY step makes sure you are in Bear Form (Dire
  Bear Form first, from level 40), then Primal Bite, Lacerate, Swipe, Maul, Faerie
  Fire, Demoralizing Roar, Enrage.

Modifiers on every step: Shift = heal (Flash of Light, Holy Light below 20 / Victory
Rush / Frenzied Regeneration), Alt = CC (Hammer of Justice / Concussion Blow / Bash),
Ctrl = interrupt (Rebuke / Shield Bash / Feral Charge).

How it works: SEQUENTIAL steps (each press = next step), plain spell names (no ranks,
no spell IDs), short macros (<= 250 characters after compiling). Forever has no
[buff]/[debuff] macro conditions, so refresh spells are timed castsequences.
Spells you have not learned yet are simply skipped. Big defensives, trinkets and DPS
are NOT in the macros. Choose the version in GSE by hand.

History
1.5.0 - All three classes rebuilt in the style of the Paladin "Prot_Leveling" that works.
1.4.x - Paladin/Warrior from the user's own sequences, ID -> names, diagnostics (the
        real cause of the "nothing happens" was a GSE update: re-place macros on the bar).
1.3.x - Level-band versions, no [buff] conditions.
