Ronin Retail V5.0.3 - tank macros for GSE (Midnight 12.0.x)
===========================================================

Tank-only pack for GSE (Gnome Sequencer Enhanced). Slash command: /ronin

12 sequences (6 tank specs x 2 hero talents), each with 3 versions:
  Mythic (all 5-man content / PvP), Raid, Delve   (Brewmaster also has "All In")

Install
  1. Extract RoninInstaller into Interface/AddOns
  2. Enable GSE + RoninInstaller, then /reload
  3. /ronin -> tick sequences -> Import Selected
  4. Put the GSE macro on your action bar and bind it.
     After every GSE update, place the macro on the bar again.

Sequences
  Protection Paladin   Lightsmith / Templar
  Brewmaster Monk      Master of Harmony / Shado-Pan (+ "All In" version with
                       Purifying and Celestial Brew)
  Guardian Druid       Elune's Chosen / Druid of the Claw (Moonfire castsequence)
  Protection Warrior   Mountain Thane / Colossus
  Vengeance DH         Aldrachi Reaver / Annihilator (castsequences, Fel
                       Devastation is never interrupted)
  Blood Death Knight   Deathbringer / San'layn (castsequence style)

How it works
  Every version is ONE Loop with StepFunction = "Priority" and small steps
  (6, sometimes 7) of 1-3 spells. With 6 steps, step 1 gets 6/21 of the key
  presses and step 6 gets 1/21, so the important spells come first.
  Death Knight and Demon Hunter use /castsequence lines that reset after a few
  seconds, so they can never get stuck.
  A talent you do not have is simply skipped.

Modifiers (hold while pressing the key)
  Shift = heal      Alt = CC
  Paladin       Word of Glory (self) / Hammer of Justice
  Brewmaster    Expel Harm (self)    / Leg Sweep
  Druid         Frenzied Regeneration / Mighty Bash
  Warrior       Impending Victory    / Shockwave
  Demon Hunter  Soul Cleave          / Chaos Nova
  Death Knight  Death Strike         / Asphyxiate
  Interrupts stay on your own keybinds.

255-character limit
  GSE limits every macro step to 255 characters AFTER compiling (it adds a space
  after every [conditional] and ';'). Every step is checked with a script that
  mirrors GSE's compiler. If your WoW client is not English, spell names are
  translated and can be longer: check the counter in the GSE editor.

Intentionally NOT included (you handle them yourself)
  Big defensives and trinkets: Ardent Defender, Guardian of Ancient Kings,
  Shield Wall, Last Stand, Fortifying Brew, Barkskin, Survival Instincts,
  Metamorphosis, Fiery Brand, Vampiric Blood, Dancing Rune Weapon, Icebound
  Fortitude, Lay on Hands, /use 13, /use 14 ...
  Macros cannot read rage/health/stagger, so active mitigation is cast
  whenever it is ready and affordable.

Notes
  - Ground spells (Death and Decay, Sigils) are cast at your feet (@player).
  - Hero-talent overrides are cast through their base spell. The two
    Brewmaster sequences are identical on purpose; they are kept separate so
    you can edit them apart.
  - Old copies already imported in GSE are not deleted by the installer.

Changelog
  5.0.3  Blood DK: removed [combat] from Death and Decay and Reaper's Mark.
  5.0.2  Vengeance: Sigil of Spite on [@player], no [combat].
  5.0.1  Vengeance: 7 steps, Immolation Aura and Sigil of Spite added.
  5.0.0  Vengeance and Blood DK in castsequence style; old versions removed.
  4.x    Priority tiers, spell list checked against Midnight 12.0.x.
